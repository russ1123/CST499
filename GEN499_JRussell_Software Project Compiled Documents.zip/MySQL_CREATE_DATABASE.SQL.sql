-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 24, 2022 at 02:27 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `empdatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `Code` varchar(40) NOT NULL,
  `Name` varchar(40) NOT NULL,
  `Description` varchar(40) NOT NULL,
  `Semester` varchar(40) NOT NULL,
  `Max` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `Code`, `Name`, `Description`, `Semester`, `Max`) VALUES
(9, 'CST310', 'Software Development', 'Description Here', 'FALL', 8),
(10, 'CST310', 'Software Development', 'Description Here', 'SPRING', 8),
(11, 'ENG121', 'Introduction to Film', 'Description Here', 'SUMMER', 10),
(12, 'MAT200', 'Statistics', 'Description Here', 'FALL', 8),
(13, 'MAT200', 'Statistics', 'Description Here', 'SPRING', 8),
(14, 'MAT200', 'Statistics', 'Description Here', 'SUMMER', 8),
(15, 'ENG300', 'Structural Engineering', 'Description Here', 'FALL', 8),
(16, 'ART300', 'Basket Weaving', 'Description Here', 'SPRING', 8),
(17, 'ENG225', 'Technical Writing', 'Description Here', 'FALL', 8),
(18, 'CST310', 'Software Development', 'Description Here', 'SUMMER', 8),
(19, 'ENG122', 'Film', 'Description Here', 'FALL', 10),
(20, 'ART300', 'Basket Weaving', 'Description Here', 'SPRING', 8),
(21, 'MAT210', 'Algebra', 'Description Here', 'SPRING', 8),
(22, 'MAT300', 'Calculus', 'Description Here', 'SUMMER', 8),
(23, 'ENG225', 'Technical Writing', 'Description Here', 'FALL', 8),
(24, 'ENG300', 'Structural Engineering', 'Description Here', 'SPRING', 8);

-- --------------------------------------------------------

--
-- Table structure for table `course_assignments`
--

CREATE TABLE `course_assignments` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `state` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course_assignments`
--

INSERT INTO `course_assignments` (`id`, `course_id`, `student_id`, `date`, `state`) VALUES
(46, 9, 3, '2022-01-18 00:26:08', 1),
(48, 9, 5, '2022-01-18 00:26:08', 1),
(49, 9, 6, '2022-01-18 00:26:08', 1),
(51, 9, 8, '2022-01-18 00:26:08', 1),
(52, 9, 9, '2022-01-18 00:26:08', 1),
(53, 9, 10, '2022-01-18 00:26:08', 1),
(81, 9, 2, '2022-01-18 01:04:49', 1),
(82, 23, 2, '2022-01-18 01:04:53', 1),
(83, 20, 2, '2022-01-18 01:07:09', 1),
(85, 8, 9, '2022-01-18 01:32:37', 1),
(87, 9, 9, '2022-01-18 01:33:51', 1),
(104, 13, 1, '2022-01-18 04:04:00', 1),
(106, 9, 1, '2022-01-18 21:39:50', 0),
(108, 23, 1, '2022-01-18 23:43:13', 1),
(109, 19, 1, '2022-01-18 23:43:18', 1),
(110, 17, 1, '2022-01-18 23:43:22', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE `tbluser` (
  `id` int(11) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `firstName` varchar(40) NOT NULL,
  `lastName` varchar(40) NOT NULL,
  `address` varchar(40) NOT NULL,
  `phone` varchar(40) NOT NULL,
  `dob` varchar(40) NOT NULL,
  `SSN` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`id`, `email`, `password`, `firstName`, `lastName`, `address`, `phone`, `dob`, `SSN`) VALUES
(1, 'jrussell17@gmail.com', 'c4ca4238a0b923820dcc509a6f75849b', '1', '1', '1', '1', '1', '1'),
(2, 'j.russell17@gmail.com', 'c4ca4238a0b923820dcc509a6f75849b', '1', '1', '1', '1', '1', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course_assignments`
--
ALTER TABLE `course_assignments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tbluser`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `course_assignments`
--
ALTER TABLE `course_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `tbluser`
--
ALTER TABLE `tbluser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
