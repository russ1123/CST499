<!DOCTYPE html>
<html lang="en">
<head>
    <title>Employee Portal Home Page</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Jonathan Russell">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="https://https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.js"></script>
</head>
<body>
<div class="container text-center">
    <h1>Welcome to the Login Page!</h1>
</div>
<nav class="navbar navbar-inverse">
 <div class="row show-grid" style="text-align:center" name ='nav'>
        <div class="col-xs-6 col-sm-1"><a href="./index.php">Home</a></div>
        <div class="col-xs-6 col-sm-1"><a href="./ContactUs.php">Contact Us</a></div>
        <?php // $GLOBALS['authed'] = true;
        //Toggle between an authenticated user menu and unauthenticated
        if (isset($_COOKIE["email"])) {
            echo '<div class="col-xs-6 col-sm-1"><a href="./profile.php">Profile</a></div>';
            echo '<div class="col-xs-6 col-sm-1"><a href="./classes.php">Classes</a></div>';
            echo '<div class="col-xs-6 col-sm-1"><a href="./catalog.php">Catalog</a></div>';
            echo '<div class="col-xs-6 col-sm-1"><a href="./logout.php">Logout</a></div>';
        } else {
            echo '<div class="col-xs-6 col-sm-1"><a href="./registration.php">Registration</a></div>';
            echo '<div class="col-xs-6 col-sm-1"><a href="./login.php">Login</a></div>';
        } ?>
    </div>
</nav>
<div>

</div>
<div>
 <!--Simple login form-->
    <form name="login" method="post" action="<?php
echo $_SERVER['PHP_SELF'];
?>">
<b>Email:</b> <input type="text" name="email"> <br><br>
        <b>Password:</b><input type="text" name="password"> <br><br>
        <input type="submit" name="submit" value="submit">
    </form>

<?php
if (isset($_COOKIE['email'])) {
	$e = $_COOKIE['email'];
	echo "Login Successful! Welcome to the employee portal, $e";
} else {
	echo "You are not logged into the system!";
}
?>
</div>
<div class="container text-center">Copyright @ 2021
</div>
</body>
</html>
<?php //Upon submit, insert the superglobal variable values into the database using the data access class
Include 'dataaccess.php';
If (isset($_REQUEST['submit']) != '') {
	If ($_REQUEST['email'] == '' || $_REQUEST['password'] == '') {
		Echo "Empty Field!";
	} Else {
		$email = $_POST['email'];
		$password = md5($_POST['password']);

		$return = new dataaccess2();
		$return->searchUser($email, $password);
		header("refresh:0");
	}
}
