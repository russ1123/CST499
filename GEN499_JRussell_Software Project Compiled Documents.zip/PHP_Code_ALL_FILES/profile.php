<!DOCTYPE html>
<html lang="en">
<head>
    <title>Profile Page</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Jonathan Russell">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="https://https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.js"></script>
</head>
<body>
<div class="container text-center">
<h1><?php if (isset($_COOKIE["email"])) {
    //Defines as Employee Role
    echo "" .
        $_COOKIE["name"] .
        " ,Welcome to Your Education Profile Page</h1>";
} else {
    echo "Unauthorized Access"; //Denies access to non-employee roles
} ?>
</div>

<nav class="navbar navbar-inverse">
 <div class="row show-grid" style="text-align:center" name ='nav'>
        <div class="col-xs-6 col-sm-1"><a href="./index.php">Home</a></div>
        <div class="col-xs-6 col-sm-1"><a href="./ContactUs.php">Contact Us</a></div>
        <?php // $GLOBALS['authed'] = true;
        //Toggle between an authenticated user menu and unauthenticated
        if (isset($_COOKIE["email"])) {
            echo '<div class="col-xs-6 col-sm-1"><a href="./profile.php">Profile</a></div>';
            echo '<div class="col-xs-6 col-sm-1"><a href="./logout.php">Logout</a></div>';
        } else {
            echo '<div class="col-xs-6 col-sm-1"><a href="./registration.php">Registration</a></div>';
            echo '<div class="col-xs-6 col-sm-1"><a href="./login.php">Login</a></div>';
        } ?>
    </div>
</nav>

<div>

</div>
<div>
<?php //PHP code to instantiate the SQL query based on the current authenticated user


include "dataaccess.php";

$profile = new dataaccess2();
$profile->getProfile();
?>
</div>
<div class="container text-center">Copyright @ 2021
</div>
</body>
</html>