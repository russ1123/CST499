
<!DOCTYPE html>
<html lang="en">
<head>
<style>
input {
  width: 150;
  clear: both;
  align: center;
}
label {
    display: inline-block;
    width:300px;
    text-align: left;
}
submit {
text-align: right;
}
</style>
    <title>Student Portal Registration Page</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Jonathan Russell">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="https://https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.js"></script>
</head>
<body>
<div class="container text-center">
    <h1>Welcome to the New Registration Page!</h1>
</div>
<nav class="navbar navbar-inverse">
    <div class="row show-grid" style="text-align:center" >
        <div class="col-xs-6 col-sm-1"><a href="./index.php">Home</a></div>
        <div class="col-xs-6 col-sm-1"><a href="./ContactUs.php">Contact Us</a></div>
        <div class="col-xs-6 col-sm-1"><a href="./Login.php">Login</a></div>
        <div class="col-xs-6 col-sm-1"><a href="./Registration.php">Registration</a></div>
    </div>
</nav>
<div><form name="register" method="post" action="<?php echo $_SERVER["PHP_SELF"];?>"> <!--Registration form-->

<p><label>Email Address:</label>
<input type="text" name="email" value=""><p>
<label>Password:</label>
<input type="password" name="password" value=""><p>
<label>First Name:</label>
<input type="text" name="firstName" value=""><p>
<label>Last Name:</label>
<input type="text" name="lastName" value=""><p>
<label>Mailing Address:</label>
<input type="text" name="address" value=""><p>
<label>Phone Number:</label>
<input type="text" name="phone" value=""><p>
<!--title:<input type="text" name="title" value=""></br>-->
<label>DOB:</label>
<input type="text" name="dob" value=""><p>
<label>Social Security Number:</label>
<input type="text" name="ssn" value=""><p>
<p align=center>
<input type="submit" name="submit" value="submit">
</form></div>
<div class="container text-center">Copyright @ 2021</div>
<?php
include "dataaccess.php";
//After clicking submit the data will be inserted into the database using the data access class
$data = new dataaccess2();
if (isset($_REQUEST["submit"]) != "") {
    if (
        $_REQUEST["email"] == "" ||
        $_REQUEST["password"] == "" ||
        $_REQUEST["firstName"] == "" ||
        $_REQUEST["lastName"] == "" ||
        $_REQUEST["address"] == "" ||
        $_REQUEST["phone"] == "" ||
        $_REQUEST["dob"] == "" ||
        $_REQUEST["ssn"] == ""
    ) {
        echo "Empty Field!";
    }
    //$check_user = "select * from tbluser where email=$_REQUEST['email'] limit 1" -see dataccess class;

    if ($data->checkUniqueEmail()) {
        //Echo "User with Email:" .$chkEmail. " already exists!";
        echo "User with Email:" .
            $_REQUEST["email"] .
            " already exists! Please try again with a different email address";
        exit();
    } else {
        //I will build this into the data access class instead of the SQL statement here. This is a workaround for now.
        $sql =
            "INSERT INTO tbluser (email,password,firstName,lastName,address,phone,dob,ssn) VALUES('" .
            $_REQUEST["email"] .
            "', '" .
            md5($_REQUEST["password"]) .
            "', '" .
            $_REQUEST["firstName"] .
            "', '" .
            $_REQUEST["lastName"] .
            "', '" .
            $_REQUEST["address"] .
            "', '" .
            $_REQUEST["phone"] .
            "', '" .
            $_REQUEST["dob"] .
            "', '" .
            $_REQUEST["ssn"] .
            "')";

        $data->executeQuery($sql);
    }
}
?>
</body>
</html>