<?php
class dataaccess2
{
    public function searchUser($email, $pass)
    {
        //Used to determine if the user is authorized with an employee role
        include "dbconfig.inc";
        $con = mysqli_connect($hostname, $username, $password, $database);
        $res = mysqli_query(
            $con,
            "Select email,password from tbluser where email = '$email' and password = '$pass'"
        );
        $result = mysqli_fetch_array($res);
        if ($result) {
            session_start();
            setcookie("email", $email);
        } else {
            echo "Login Failed";
        }
    }

    //$_COOKIE['email']
    public function getProfile()
    {
        //New function to simplify the profile data select from the DB, no values are passed

        if (isset($_COOKIE["email"])) {
            //Stop unauthenticated access to the profile page using the login cookie
            include "dbconfig.inc";
            $acct = $_COOKIE["email"];
            $con = mysqli_connect($hostname, $username, $password, $database);
            $res = mysqli_query(
                $con,
                "Select * from tbluser where email = '$acct'"
            ); //
            //$result = mysqli_fetch_array($res);
            if (mysqli_num_rows($res) > 0) {
                while ($row = mysqli_fetch_assoc($res)) {
                    echo "ID/Email: " .
                        $row["email"] .
                        "<br>" .
                        "First Name: " .
                        $row["firstName"] .
                        "<br>" .
                        "Last Name: " .
                        $row["lastName"] .
                        "<br>" .
                        "Address: " .
                        $row["address"] .
                        "<br>" .
                        "Phone: " .
                        $row["phone"] .
                        "<br>" .
                        "DOB: " .
                        $row["dob"] .
                        "<BR>" .
                        "Social Security Number: " .
                        $row["SSN"] .
                        "<BR>" .
                        "Password: " .
                        $row["password"]; //A tedious but effective way to map the sql result values to html
                    $sname = $row["firstName"];
                    setcookie("name", $sname); //Returns results for the profile
                }
            }
        } else {
            echo "Please Log in To View Your Profile";
        }
    }
    public function executeQuery($sql)
    {
        //pull in the database configuration
        include "dbconfig.inc";
        $con = mysqli_connect($hostname, $username, $password, $database);
        $result = mysqli_query($con, $sql); //Saves registration information to the database

        if ($result) {
            echo "Thank you for enrolling into the school system!";
        } else {
            echo "There was a problem saving your information, please try again!";
        }
    }
    public function checkUniqueEmail()
    {
      try{
        include "dbconfig.inc";
        $query =
            "select * from tbluser where email='" .
            $_REQUEST["email"] .
            "' limit 1";
        $con = mysqli_connect($hostname, $username, $password, $database);
        $result = mysqli_query($con, $query);
        $email = mysqli_fetch_assoc($result);

        if ($email) {
            return true; //This means there is a match for $_REQUEST['email'];
        }
        }
        catch(exception $e){
        echo $e;

        }
    }

    public function getCourseCatalog()
    {
       try {
        include "dbconfig.inc";

        $con = mysqli_connect($hostname, $username, $password, $database);

        $query_student_id =
            "select id from tbluser where email='" .
            $_COOKIE["email"] .
            "' limit 1";
        $student_id = mysqli_query($con, $query_student_id);
        $student_id = mysqli_fetch_assoc($student_id);
        $student_id = $student_id["id"];

        $query =
            "select id,Code,Name,Semester,Max from courses order by Semester";
        $result = mysqli_query($con, $query);

        // $courses = mysqli_fetch_assoc($result);
        // return $result;
        if ($result) {
            // return $result //This means there is a match for $_REQUEST['email'];
            while ($courses = mysqli_fetch_array($result)) {
                $is_reg_query =
                    "select id,state from course_assignments where student_id= " .
                    $student_id .
                    " AND course_id = " .
                    $courses["id"] .
                    " limit 1";

                $yup = mysqli_query($con, $is_reg_query);
                $yup = mysqli_fetch_assoc($yup);
                $query_capacity =
                    "select count(*) as count from course_assignments where course_id=" .
                    $courses["id"] .
                    " AND STATE='1'";
                $capacity = mysqli_query($con, $query_capacity);
                $capacity = mysqli_fetch_assoc($capacity);
                $capacity = $capacity["count"];
                echo "<tr>";
                echo "<td>" . $courses["id"] . "</td>";
                echo "<td>" . $courses["Code"] . "</td>";
                echo "<td>" . $courses["Name"] . "</td>";
                echo "<td>" . $courses["Semester"] . "</td>";
                echo "<td>" . $courses["Max"] . "</td>";
                echo "<td>" . $capacity . "</td>"; //or here...

                if ($yup['state']==='1') {
                                   echo "<td><a href=#>Added Successfully</a></td>";
                               }
                               if (!$yup) {
                                   if ($capacity >= $courses["Max"]) {

                                   if ($yup['state']==='0'){


                                        echo "<td><a href=reserve.php?id=" .
                                        $courses["id"] .
                                        ">Course is Reserved</a></td>";
                                           }
                                           else {
                                       echo "<td><a href=reserve.php?id=" .
                                           $courses["id"] .
                                           ">Reserve Course</a></td>";
                                           }

                                   } else {
                                       echo "<td><a href=add.php?id=" .
                                           $courses["id"] .
                                           ">Add Course</a></td>";
                                   }



                               }
                               /*if ($capacity>=$courses['Max']) {
                                      echo "<td><a href=reserve.php?id=".$courses['id'].">Reserve Course</a></td>";
                                      }*/
                               /*else {
                                      echo "<td><a href=#>Course is Reserved</a></td>";
                                      }*/

                               $capacity = 0;
                               // }

                }
                           echo "</tr>";
                       }
                       }
                       catch(exception $e){
                       echo $e;
                       }
    }


    public function changeCourseToStudent($id, $email, $option)
    {
       try{
        include "dbconfig.inc"; //ALREADY REGISTERED CASES?
        $con = mysqli_connect($hostname, $username, $password, $database);

        $query_student_id =
            "select id from tbluser where email='" .
            $_COOKIE["email"] .
            "' limit 1";
        $student_id = mysqli_query($con, $query_student_id);
        // $student_idf = mysqli_fetch_assoc($student_id);
        $student_idf = mysqli_fetch_assoc($student_id);
        //echo $id;
        $student_id = $student_idf["id"];
        //echo $student_idf['id'];

        $query_capacity =
            "select count(*) as count from course_assignments where course_id=" .
            $id .
            "";
        $capacity = mysqli_query($con, $query_capacity);
        $capacity = mysqli_fetch_assoc($capacity);
        $capacity = $capacity["count"];
       // echo $capacity;

        if ($option == "ADD") {
            $insert =
                "insert into course_assignments (course_id,student_id,state) values (" .
                $id .
                "," .
                $student_id .
                ",'1')";
            $result = mysqli_query($con, $insert);
        }
        if ($option == "DELETE") {
            $delete =
                "delete from course_assignments where course_id=" .
                $id .
                " AND student_id=" .
                $student_id .
                "";
            $result = mysqli_query($con, $delete);
        }
        if ($option == "RESERVE") {
            $insert =
                "insert into course_assignments (course_id,student_id,state) values (" .$id.
                "," .
                $student_id .
                ",'0')";
            $result = mysqli_query($con, $insert);
        }}
        catch(exception $e){
        echo $e;
        }
    }

    public function getClasses()
    {
        include "dbconfig.inc";
        try {
        $con = mysqli_connect($hostname, $username, $password, $database);

        $query_student_id =
            "select id from tbluser where email='" .
            $_COOKIE["email"] .
            "' limit 1";
        $student_id = mysqli_query($con, $query_student_id);
        $student_id = mysqli_fetch_assoc($student_id);
        $student_id = $student_id["id"];

        $query = "select id,Code,Name,Semester,Max from courses order by Semester";
        $result = mysqli_query($con, $query);

        // $courses = mysqli_fetch_assoc($result);
        // return $result;
        if ($result) {
            // return $result //This means there is a match for $_REQUEST['email'];
            while ($courses = mysqli_fetch_array($result)) {
                $is_reg_query =
                    "select id,state from course_assignments where student_id = " .
                    $student_id .
                    " AND course_id = " .
                    $courses["id"] .
                    " limit 1";

                $yup = mysqli_query($con, $is_reg_query);
                $yup = mysqli_fetch_assoc($yup);
                if ($yup) {
                    echo "<tr>";
                    echo "<td>" . $courses["id"] . "</td>";
                    echo "<td>" . $courses["Code"] . "</td>";
                    echo "<td>" . $courses["Name"] . "</td>";
                    echo "<td>" . $courses["Semester"] . "</td>";
                    echo "<td>" . $courses["Max"] . "</td>";
                    if ($yup["state"] === "1") {
                        echo "<td><a href=delete.php?id=" .
                            $courses["id"] .
                            ">Delete Course</a></td>";
                    } else {
                        echo "<td><a href=delete.php?id=" .
                            $courses["id"] .
                            ">Delete Reserved Course</a></td>";
                    }
                }
                echo "</tr>";
            }
        }}
        catch(exception $e){
        echo $e;
        }
    }

    public function nextStudent($course_id){


            include "dbconfig.inc";

            $con = mysqli_connect($hostname, $username, $password, $database);
            $query = "select ca.student_id,min(ca.date),u.email as winner from course_assignments ca,tbluser u where state=0 and course_id=".$course_id."limit 1"  ;

            $query=mysqli_query($con, $query);
            $query= mysqli_fetch_assoc($query);
            $email=$query['email'];
            $student=$query['student_id'];

            //if($query){

            mail("jrussell17@gmail.com","d","d","From: <jrussell17@gmail.com>");

            echo $email;
           }







}
