<?php
include "dataaccess.php";

$add = new dataaccess2();
$id = $_GET['id'];
$email = $_COOKIE['email'];
$add->changeCourseToStudent($id, $email,"ADD");

//echo "<script>alert('dd')</script>";


header("Location: //127.0.0.1/catalog.php");

?>