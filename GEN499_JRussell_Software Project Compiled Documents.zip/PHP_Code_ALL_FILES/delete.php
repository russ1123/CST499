<?php
include "dataaccess.php";

$add = new dataaccess2();
$id = $_GET['id'];
$email = $_COOKIE['email'];
$add->changeCourseToStudent($id, $email,"DELETE");

//echo "<script>alert('dd')</script>";
$lastStudent= new dataaccess2();
$lastStudent->nextStudent($id);

$_COOKIE['id2']=$_GET['id'];


header("Location: //127.0.0.1/classes.php");

?>