<?php
setcookie("email", "", time() - 3600); //Invalidates the employee role authorization cookie

header("Location: //127.0.0.1/login.php"); //redirects to the login page
?>
