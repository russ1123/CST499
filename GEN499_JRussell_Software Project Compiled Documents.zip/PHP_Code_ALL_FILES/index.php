<!DOCTYPE html>
<html lang="en">
<head>
    <title>Employee Portal Home Page</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Jonathan Russell">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="https://https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.js"></script>
</head>
<body>
<div class="container text-center">
<h1>Welcome to the Home Page!</h1>
</div>
<!--Top Nav-->
<nav class="navbar navbar-inverse">
 <div class="row show-grid" style="text-align:center" name ='nav'>
        <div class="col-xs-6 col-sm-1"><a href="./Home.php">Home</a></div>
        <div class="col-xs-6 col-sm-1"><a href="./ContactUs.php">Contact Us</a></div>

        <?php
     // $GLOBALS['authed'] = true;

        if(isset($_COOKIE['email'])) {
            echo '<div class="col-xs-6 col-sm-1"><a href="./profile.php">Profile</a></div>';
            echo '<div class="col-xs-6 col-sm-1"><a href="./logout.php">Logout</a></div>';
        }
        else {
            echo '<div class="col-xs-6 col-sm-1"><a href="./registration.php">Registration</a></div>';
            echo '<div class="col-xs-6 col-sm-1"><a href="./login.php">Login</a></div>';
             }
        ?>
    </div>
</nav>

<div>
Some content here!
</div>
<div>  <!--Secondary navigation menu is here-->
<ul class="jumbotron">
    <li class="active"><a href="./Home.php">Home</a></li>
    <li><a href="./ContactUs.php">Contact Us</a></li>
    <li><a href="./Login.php">Login</a></li>
    <li><a href="./Registration.php">Registration</a></li>
</ul>
</div>
<div class="container text-center">Copyright @ 2021
</div>
</body>
</html>